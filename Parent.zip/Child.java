class Child extends Parent {
	public void method1() {
		System.out.println ("Child's method1()");
	} 
	public static void main(String args[]) {
		Parent p = new Child();
		p.method2();
	}
}

/* Solution */
/*Output of the code will option C:
	C. Prints : Parent's method2()
	 Parent's method1()

Because program creates an object for Child class and goes to check 
method2() in Child and Parent class because child class inherits parent class.
Program finds method2() in Parent thus prints "Parent's method2()" and then
since method2() calls method1(), it goes to print "Parent's method1()" from method1().
Thus the correct answer is option C */